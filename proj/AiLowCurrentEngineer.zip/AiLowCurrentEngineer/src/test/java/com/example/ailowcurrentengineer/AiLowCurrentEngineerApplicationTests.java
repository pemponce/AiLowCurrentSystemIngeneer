package com.example.ailowcurrentengineer;

import org.aspectj.weaver.ast.Call;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;

import static org.hamcrest.MatcherAssert.assertThat;

@SpringBootTest
class AiLowCurrentEngineerApplicationTests {

    @Test
    void contextLoads() {
    }

}
